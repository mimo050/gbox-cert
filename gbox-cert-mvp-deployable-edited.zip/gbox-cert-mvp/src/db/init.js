import Database from 'better-sqlite3';
import path from 'path';
const dbPath = path.join(process.cwd(), 'data.sqlite');
const db = new Database(dbPath);
db.exec(`
PRAGMA journal_mode = WAL;
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT,
  udid TEXT,
  price_cents INTEGER DEFAULT 0,
  status TEXT DEFAULT 'pending',
  paymob_order_id TEXT,
  paymob_txn_id TEXT,
  code_id INTEGER,
  cert_url TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS codes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT UNIQUE,
  is_used INTEGER DEFAULT 0,
  order_id INTEGER
);
CREATE TRIGGER IF NOT EXISTS orders_updated_at
AFTER UPDATE ON orders
FOR EACH ROW
BEGIN
  UPDATE orders SET updated_at = CURRENT_TIMESTAMP WHERE id = OLD.id;
END;
`);
console.log('DB initialized at', dbPath);
db.close();