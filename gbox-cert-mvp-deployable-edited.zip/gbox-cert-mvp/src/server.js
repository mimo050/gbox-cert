import 'dotenv/config';
import express from 'express';
import bodyParser from 'body-parser';
import crypto from 'crypto';
import path from 'path';
import db from './db/index.js';
import fetch from 'node-fetch';
import fs from 'fs';

const app = express();
const port = process.env.PORT || 3000;
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src/views'));
app.use(express.static(path.join(process.cwd(), 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Home - order form
app.get('/', (req, res) => {
  res.render('index');
});

// Create order & redirect to Paymob iframe
app.post('/checkout', async (req, res) => {
  try {
    const { email, udid, method } = req.body;
    const payMethod = (method === 'applepay') ? 'applepay' : 'card';
    const priceCents = 1500; // change as needed

    const stmt = db.prepare('INSERT INTO orders (email, udid, price_cents) VALUES(?,?,?)');
    const info = stmt.run(email, udid, priceCents);
    const orderId = info.lastInsertRowid;

    // Paymob: auth token
    const authRes = await fetch('https://accept.paymob.com/api/auth/tokens', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ api_key: process.env.PAYMOB_API_KEY })
    });
    const auth = await authRes.json();

    // Paymob: order registration
    const orderRes = await fetch('https://accept.paymob.com/api/ecommerce/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        auth_token: auth.token,
        delivery_needed: false,
        amount_cents: priceCents.toString(),
        currency: 'SAR',
        merchant_order_id: `ORD-${orderId}-${Date.now()}`,
        items: []
      })
    });
    const order = await orderRes.json();

    db.prepare('UPDATE orders SET paymob_order_id=? WHERE id=?').run(order.id?.toString() ?? null, orderId);

    const integrationId = payMethod === 'applepay'
      ? parseInt(process.env.APPLEPAY_INTEGRATION_ID)
      : parseInt(process.env.CARD_INTEGRATION_ID);

    // Paymob: payment key
    const payKeyRes = await fetch('https://accept.paymob.com/api/acceptance/payment_keys', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        auth_token: auth.token,
        amount_cents: priceCents.toString(),
        currency: 'SAR',
        order_id: order.id,
        billing_data: {
          apartment: "NA", email, floor: "NA", first_name: "Customer",
          street: "NA", building: "NA", phone_number: "NA", shipping_method: "NA",
          postal_code: "NA", city: "Riyadh", country: "SAU", last_name: "NA", state: "NA"
        },
        integration_id: integrationId,
        lock_order_when_paid: true
      })
    });
    const payKey = await payKeyRes.json();

    const iframeId = payMethod === 'applepay'
      ? process.env.APPLEPAY_IFRAME_ID
      : process.env.CARD_IFRAME_ID;

    res.render('pay', { iframeId, paymentToken: payKey.token, orderId, method: payMethod });
  } catch (e) {
    console.error(e);
    res.status(500).send('Payment init error');
  }
});

// Paymob Webhook
app.post('/paymob/webhook', (req, res) => {
  try {
    const hmac = req.query.hmac;
    const secret = process.env.PAYMOB_HMAC_SECRET;
    const received = req.body;

    const keys = [
      'amount_cents','created_at','currency','error_occured','has_parent_transaction','id','integration_id',
      'is_3d_secure','is_auth','is_capture','is_refunded','is_standalone_payment','is_voided','order.id',
      'owner','pending','source_data.pan','source_data.sub_type','source_data.type','success'
    ];

    const str = keys.map(k => {
      const parts = k.split('.');
      let val = received;
      for (const p of parts) val = val?.[p];
      return String(val ?? '');
    }).join('');

    const calc = crypto.createHmac('sha512', secret).update(str).digest('hex');

    if (calc !== hmac) {
      console.warn('HMAC mismatch');
      return res.status(401).send('Invalid HMAC');
    }

    const paySuccess = received.success === true || received.success === 'true';
    const orderId = received.order?.merchant_order_id?.split('-')[1];

    if (paySuccess && orderId) {
      db.prepare('UPDATE orders SET status=? , paymob_txn_id=? WHERE id=?')
        .run('paid', received.id?.toString() ?? null, orderId);
      queueIssue(parseInt(orderId));
    }

    res.sendStatus(200);
  } catch (e) {
    console.error(e);
    res.sendStatus(500);
  }
});

// Simple queue
const queue = [];
function queueIssue(orderId) { queue.push(orderId); }

app.get('/orders/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const order = db.prepare('SELECT * FROM orders WHERE id=?').get(id);
  if (!order) return res.status(404).send('Not found');
  res.render('order', { order });
});

// Minimal worker trigger: poll queue and drop JSON payloads
setInterval(() => {
  const id = queue.shift();
  if (!id) return;
  try {
    const order = db.prepare('SELECT * FROM orders WHERE id=?').get(id);
    if (!order || order.status !== 'paid') return;

    const code = db.prepare('SELECT * FROM codes WHERE is_used=0 LIMIT 1').get();
    if (!code) {
      console.error('No codes left');
      db.prepare('UPDATE orders SET status=? WHERE id=?').run('failed', id);
      return;
    }
    db.prepare('UPDATE orders SET status=?, code_id=? WHERE id=?').run('issuing', code.id, id);
    db.prepare('UPDATE codes SET is_used=1, order_id=? WHERE id=?').run(id, code.id);

    const payloadPath = path.join(process.cwd(), `tmp_issue_${id}.json`);
    fs.writeFileSync(payloadPath, JSON.stringify({ udid: order.udid, code: code.code, id }));
    console.log('Wrote worker payload', payloadPath);
  } catch (e) {
    console.error('Queue worker error', e);
  }
}, 5000);

app.listen(port, () => console.log(`Server running on http://localhost:${port}`));
