import 'dotenv/config';
import fs from 'fs';
import path from 'path';
import { chromium } from 'playwright';

const gboxUrl = process.env.GBOX_URL || 'https://gbox.run';

/**
 * Issuer: opens gbox.run, fills UDID + code, clicks "بداية" then "تحميل الشهادة",
 * saves the downloaded file, updates DB, and emails it as attachment + link.
 */
async function runOnce(file) {
  const data = JSON.parse(fs.readFileSync(file, 'utf-8'));
  const { udid, code, id } = data;

  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ acceptDownloads: true });
  if (process.env.GBOX_COOKIE) {
    const [name, value] = process.env.GBOX_COOKIE.split('=', 2);
    await context.addCookies([{ name, value, url: gboxUrl }]);
  }
  const page = await context.newPage();
  await page.goto(gboxUrl, { waitUntil: 'load', timeout: 120000 });

  // --- Fill inputs (first is UDID, second is code) ---
  const inputs = page.locator('input');
  await inputs.nth(0).fill(udid, { timeout: 20000 });
  await inputs.nth(1).fill(code, { timeout: 20000 });

  // Click "بداية" (Start) if موجود
  try {
    await page.getByRole('button', { name: /بداية/ }).click({ timeout: 5000 });
  } catch {}

  // Click "تحميل الشهادة" and wait for the download
  const download = await Promise.race([
    page.waitForEvent('download', { timeout: 30000 }),
    (async () => {
      await page.getByRole('button', { name: /تحميل الشهادة/ }).click();
      return await page.waitForEvent('download', { timeout: 60000 });
    })()
  ]);

  const dir = path.join(process.cwd(), 'public', 'certs');
  fs.mkdirSync(dir, { recursive: true });
  const suggested = download.suggestedFilename();
  const outPath = path.join(dir, `ord_${id}__${suggested || 'certificate.mobileconfig'}`);
  await download.saveAs(outPath);

  await browser.close();

  // Update DB with URL and send email
  const db = (await import('../src/db/index.js')).default;
  const url = `/certs/${path.basename(outPath)}`;
  db.prepare('UPDATE orders SET status=?, cert_url=? WHERE id=?').run('done', url, id);

  try {
    const ord = db.prepare('SELECT * FROM orders WHERE id=?').get(id);
    const { sendCertEmail } = await import('../src/mailer.js');
    const base = process.env.BASE_URL || '';
    const link = `${base}${url}`;
    const to = ord?.email;
    if (to) {
      await sendCertEmail({ to, link, orderId: id, attachmentPath: outPath });
      console.log('Email sent to', to);
    }
  } catch(e){ console.error('Email send error', e); }

  fs.unlinkSync(file);
  console.log('Issued certificate for order', id, '->', outPath);
}

(async () => {
  setInterval(async () => {
    const files = fs.readdirSync(process.cwd()).filter(f => f.startsWith('tmp_issue_') && f.endsWith('.json'));
    for (const f of files) {
      try { await runOnce(path.join(process.cwd(), f)); } catch (e) { console.error('Worker error', e); }
    }
  }, 3000);
})();
