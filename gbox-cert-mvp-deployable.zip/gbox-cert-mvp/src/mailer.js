import nodemailer from 'nodemailer';
export async function sendCertEmail({ to, link, orderId, attachmentPath }) {
  const host = process.env.SMTP_HOST;
  const port = parseInt(process.env.SMTP_PORT || '587', 10);
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  const from = process.env.FROM_EMAIL || `Certificates <${user}>`;
  const transporter = nodemailer.createTransport({ host, port, secure: port===465, auth:{user, pass} });

  const html = `<div style="font-family:system-ui">
    <h3>تم إصدار شهادتك ✅</h3>
    <p>رقم الطلب: <b>#${orderId}</b></p>
    <p>رابط التحميل:</p>
    <p><a href="${link}" target="_blank">${link}</a></p>
    <hr><small>أرفقنا الشهادة أيضًا كمرفق.</small>
  </div>`;
  const text = `تم إصدار شهادتك. رقم الطلب #${orderId}\nرابط التحميل: ${link}\n`;

  const mailOptions = { from, to, subject: `شهادتك جاهزة - طلب #${orderId}`, text, html };
  if (attachmentPath) {
    mailOptions.attachments = [{ filename: attachmentPath.split('/').pop(), path: attachmentPath }];
  }
  await transporter.sendMail(mailOptions);
}