# GBox Certificate MVP (Card + Apple Pay)

- صفحة طلب تجمع البريد + UDID + اختيار طريقة الدفع (بطاقة أو Apple Pay).
- دمج Paymob لطريقتين بمتغيرات بيئة منفصلة.
- Webhook يتحقق بـ HMAC ويطلق عامل الإصدار.
- عامل (Playwright) يذهب إلى gbox.run لإصدار الشهادة (يلزم ضبط السيلكتورز) ثم يرسل رابط التحميل على الإيميل.

## تشغيل
```
npm i
npm run init:db
cp .env.example .env  # عدّل القيم
npm run dev           # نافذة 1
npm run worker        # نافذة 2
```
افتح: `http://localhost:3000`
